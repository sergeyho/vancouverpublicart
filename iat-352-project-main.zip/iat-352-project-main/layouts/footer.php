
<!-- Footer -->

<?php html_footers(); ?>